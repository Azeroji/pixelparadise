(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 7999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 8188:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6594)), "C:\\Users\\pc\\Desktop\\React\\dalil\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5596)), "C:\\Users\\pc\\Desktop\\React\\dalil\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\pc\\Desktop\\React\\dalil\\app\\page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 7115:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6714))

/***/ }),

/***/ 7460:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9222, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3751, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4765, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8301, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5192, 23))

/***/ }),

/***/ 6477:
/***/ (() => {



/***/ }),

/***/ 6714:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/react-icons/ci/index.esm.js
var index_esm = __webpack_require__(1408);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var io_index_esm = __webpack_require__(5780);
;// CONCATENATED MODULE: ./components/Navbar/Navbar.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const Navbar = (props)=>{
    const [open, setOpen] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "font-FiraCode",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between items-center py-[7%] md:py-[25px] md:px-[3%] px-[10%]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Dalil ADIMI"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "text-GRAY md:flex gap-x-[40px] items-center text-[15px] font-medium hidden",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#About",
                                className: "hover:text-TXT cursor-pointer",
                                children: "About"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#Work",
                                className: "hover:text-TXT cursor-pointer",
                                children: "Work"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#Contact",
                                className: "hover:text-TXT cursor-pointer",
                                children: "Contact"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://dalil_adimi.tiiny.site",
                                className: "text-center text-TXT border border-TXT px-[15px] py-[8px] hover:bg-TXT hover:text-BG rounded-[3px]",
                                children: "Resume"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "block md:hidden",
                        children: open ? /*#__PURE__*/ jsx_runtime_.jsx(io_index_esm/* IoMdClose */.QAE, {
                            size: 30,
                            onClick: ()=>{
                                setOpen(false);
                            }
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* CiMenuFries */.F3G, {
                            size: 30,
                            onClick: ()=>{
                                setOpen(true);
                            }
                        })
                    })
                ]
            }),
            open && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[100%] md:hidden flex justify-center text-center bottom-[-200%] py-[20px] shadow-lg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "flex flex-col text-GRAY leading-[40px] items-center text-[15px] font-medium",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#About",
                                className: "hover:text-TXT cursor-pointer",
                                children: "About"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#Work",
                                className: "hover:text-TXT cursor-pointer",
                                children: "Work"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#Contact",
                                className: "hover:text-TXT cursor-pointer",
                                children: "Contact"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://dalil_adimi.tiiny.site",
                                className: "text-center text-TXT border border-TXT px-[15px] mt-[20px] py-[15px] hover:bg-TXT hover:text-BG rounded-[3px] leading-none",
                                children: "Resume"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const Navbar_Navbar = (Navbar);

;// CONCATENATED MODULE: ./components/HomePage/HomePage.tsx



const HomePage = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex justify-center pt-[20%] pb-[35%] md:py-[10%]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-[85%] md:w-[60%] flex flex-col gap-y-[20px]",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "text-TXT font-FiraCode leading-none",
                    children: "Hello, my name is"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-white font-Poppins font-semibold text-[32px] md:text-[60px] leading-none",
                    children: [
                        "Dalil ADIMI",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-TXT",
                            children: "."
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-GRAY font-Poppins font-semibold text-[32px] md:text-[60px] leading-none",
                    children: [
                        "I am a ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-TXT",
                            children: "Full Stack Web Developer"
                        }),
                        "."
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "text-GRAY font-FiraCode w-[60%]",
                    children: "I've built and conceived multiple web projects both front-only and full stack applications"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "#Contact",
                    className: "text-center hover:text-TXT font-FiraCode border border-TXT px-[15px] py-[8px] hover:bg-BG bg-TXT text-BG rounded-[3px] w-[150px] font-medium mt-[5%]",
                    children: "Contact me"
                })
            ]
        })
    });
};
/* harmony default export */ const HomePage_HomePage = (HomePage);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/About/About.tsx



const About = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "About",
        className: "flex justify-center py-[7%]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-[85%] md:w-[60%] font-FiraCode flex flex-col gap-y-[20px] text-GRAY",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center gap-x-[20px] md:w-[50%]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-Poppins font-semibold text-white text-[20px] md:text-[28px]",
                            children: "About me"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "border-t w-[50%] md:w-[70%] border-[#233554]"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between items-center gap-x-[5%]",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col gap-y-[20px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Hello! my name is Dalil and I am currently pursuing my studies in Computer Science at the National Higher School of Computer Science in Algiers, Algeria."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "I enjoy the process of web development, from conceiving and designing websites to bringing them to life. Moreover, I have recently ventured into machine learning and data science, exploring the fascinating realms of extracting insights and building intelligent systems."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Here are some technologies I have been working with recently :"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex w-[100%] justify-around items-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "flex flex-col gap-y-[10px] w-[45%]",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "text-TXT border border-TXT px-[15px] py-[8px] rounded-[3px]",
                                                    children: "TypeScript"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "text-TXT border border-TXT px-[15px] py-[8px] rounded-[3px]",
                                                    children: "Next.js"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "text-TXT border border-TXT px-[15px] py-[8px] rounded-[3px]",
                                                    children: "Tailwind css"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "text-TXT border border-TXT px-[15px] py-[8px] rounded-[3px]",
                                                    children: "Python"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "flex flex-col gap-y-[10px] w-[45%]",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "text-TXT border border-TXT px-[15px] py-[8px] rounded-[3px]",
                                                    children: "JavaScript"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "text-TXT border border-TXT px-[15px] py-[8px] rounded-[3px]",
                                                    children: "Node.js"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "text-TXT border border-TXT px-[15px] py-[8px] rounded-[3px]",
                                                    children: "Express.js"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "text-TXT border border-TXT px-[15px] py-[8px] rounded-[3px]",
                                                    children: "MySQL"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "lg:block hidden",
                            src: "/images/about.svg",
                            alt: "logo",
                            width: "512",
                            height: "512"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const About_About = (About);

;// CONCATENATED MODULE: ./components/Work/Work.tsx


const Work = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "Work",
        className: "flex justify-center py-[5%]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-[85%] md:w-[60%] font-FiraCode flex flex-col gap-y-[20px] text-GRAY",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center justify-center gap-x-[20px] md:w-[100%]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "border-t w-[50%] md:w-[30%] border-[#233554]"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-Poppins font-semibold text-white text-[20px] md:text-[28px] text-center",
                            children: "Some Things I've Built"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "border-t w-[50%] md:w-[30%] border-[#233554]"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "my-[50px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-TXT leading-none",
                                    children: "Featured"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://github.com/Azeroji/CHAT-APPS",
                                    className: "font-Poppins font-semibold text-GRAY text-[16px] md:text-[22px]",
                                    children: "Chat App"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "mt-[20px] p-[30px] bg-[#112240] rounded-[3px]",
                                    children: [
                                        "Built a full stack instantaneous messaging website using ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-TXT",
                                            children: "React"
                                        }),
                                        ", ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-TXT",
                                            children: "Tailwind"
                                        }),
                                        ", ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-TXT",
                                            children: "Node.js"
                                        }),
                                        ",",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-TXT",
                                            children: " Express.js"
                                        }),
                                        " and ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-TXT",
                                            children: "MySQL"
                                        }),
                                        "."
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "my-[50px] text-right",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-TXT leading-none mt-[]",
                                    children: "Featured"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://github.com/Azeroji/store",
                                    className: "font-Poppins font-semibold text-GRAY text-[16px] md:text-[22px]",
                                    children: "Online Store"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "mt-[20px] p-[30px] bg-[#112240] rounded-[3px]",
                                    children: [
                                        "Built a front-end only Online Store using ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-TXT",
                                            children: "React"
                                        }),
                                        " and ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-TXT",
                                            children: "Tailwind"
                                        }),
                                        "."
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "my-[50px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-TXT leading-none mt-[]",
                                    children: "Featured"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://github.com/Azeroji/netflix",
                                    className: "font-Poppins font-semibold text-GRAY text-[16px] md:text-[22px]",
                                    children: "Netflix Replica"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "mt-[20px] p-[30px] bg-[#112240] rounded-[3px]",
                                    children: [
                                        "Built a front-end only Netflix Replica using ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-TXT",
                                            children: "React"
                                        }),
                                        "."
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Work_Work = (Work);

// EXTERNAL MODULE: ./node_modules/react-icons/fi/index.esm.js
var fi_index_esm = __webpack_require__(7808);
;// CONCATENATED MODULE: ./components/Contact/Contact.tsx





const Contact = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "Contact",
        className: "flex justify-center py-[7%]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-[85%] md:w-[60%] font-FiraCode flex flex-col gap-y-[20px] text-GRAY",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center justify-center gap-x-[20px] md:w-[100%]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "border-t w-[50%] md:w-[30%] border-[#233554]"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-Poppins font-semibold text-white text-[20px] md:text-[28px] text-center",
                            children: "Contact me"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "border-t w-[50%] md:w-[30%] border-[#233554]"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col gap-y-[40px] mt-[10%]",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: "https://github.com/Azeroji",
                            className: "hover:text-TXT flex gap-x-[20px] items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiGithub */.uOf, {
                                    size: 24
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-[16px]",
                                    children: "Azeroji"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: "https://www.linkedin.com/in/dalil-adimi-632967264/",
                            className: "hover:text-TXT flex gap-x-[20px] items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiLinkedin */.qOw, {
                                    size: 24
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-[16px]",
                                    children: "Dalil ADIMI"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: "#",
                            className: "hover:text-TXT flex gap-x-[20px] items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(fi_index_esm/* FiMail */.Imn, {
                                    size: 24
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-[16px]",
                                    children: "md_adimi@esi.dz"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Contact_Contact = (Contact);

;// CONCATENATED MODULE: ./components/Footer/Footer.tsx


const Footer = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "Footer",
        className: "flex justify-center text-center font-FiraCode text-GRAY pb-[50px] mt-[50px]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
            children: [
                "Built by me using ",
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-TXT",
                    children: "Next.js"
                }),
                ", ",
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-TXT",
                    children: "TypeScript"
                }),
                " and ",
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-TXT",
                    children: "Tailwind"
                }),
                "."
            ]
        })
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

;// CONCATENATED MODULE: ./app/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: "text-TXT h-[100%] flex flex-col bg-BG",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar_Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_HomePage, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(About_About, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Work_Work, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Contact_Contact, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {})
        ]
    });
}


/***/ }),

/***/ 5596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   "metadata": () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5035);
/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2817);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);



const metadata = {
    title: "Portfolio"
};
function RootLayout({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
            className: (next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default().className),
            children: children
        })
    });
}


/***/ }),

/***/ 6594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\pc\Desktop\React\dalil\app\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 4756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2548);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 2817:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [859,21], () => (__webpack_exec__(8188)));
module.exports = __webpack_exports__;

})();